import SortQueue from "@/components/SortQueue";

export default function Home() {
  

  return (
    <>
      <SortQueue />
    </>
  );
}
